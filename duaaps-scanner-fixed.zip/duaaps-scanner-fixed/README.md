# DUAAPS Scanner – Android (Capacitor + ML Kit)

## Build the APK

Requirements: Node 18+/20, JDK 17, Android SDK (Android Studio installs it).

    npm install
    npx cap sync android
    cd android && ./gradlew assembleDebug        (Windows: gradlew.bat assembleDebug)

or just run `./build-apk.sh` (`build-apk.bat` on Windows).
APK: `android/app/build/outputs/apk/debug/app-debug.apk`

GitHub Actions: push to `main` and download the `duaaps-scanner-debug-apk` artifact.
Commit `package-lock.json` (included) – the workflow uses `npm ci`.

## Camera permission – how it works now
- Camera is requested in ONE place: `BarcodeScanner.requestPermissions()` in `www/app.js`,
  right after the PIN is accepted. `MainActivity` is a plain `BridgeActivity` (no extra launchers).
- If it was denied before: uninstall/reinstall, or Settings > Apps > DUAAPS Scanner > Permissions > Camera.
  The in-app "Open App Settings" button does this; the scanner restarts automatically on return.

## Changes vs. the previous zip
- app.js had a syntax error (multi-line string in `alert`) that stopped the whole script.
- Removed 3 overlapping permission requests (MainActivity launcher, DOMContentLoaded, startCamera).
- Plugin is registered with `Capacitor.registerPlugin('BarcodeScanner')` (no bundler).
- Added Gradle wrapper (gradlew, jar), launcher icons, regenerated Capacitor Gradle files.
- Added package-lock.json; fixed CI; fixed `extractId` regex; reused one AudioContext.
- `allowBackup=false` (saved PIN is not backed up), cleartext traffic disabled (endpoint is https).
- minSdk 23, Capacitor 6.
