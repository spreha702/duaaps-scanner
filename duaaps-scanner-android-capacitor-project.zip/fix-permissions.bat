@echo off
node scripts\inject-permissions.js
echo Camera permissions successfully injected into AndroidManifest.xml!
pause
