#!/usr/bin/env bash
echo "=== Building DUAAPS Native Android Scanner APK ==="
set -e

npm install
node scripts/inject-permissions.js
npx cap sync android

cd android
chmod +x gradlew || true
./gradlew assembleDebug

echo ""
echo "SUCCESS! APK built at:"
echo "android/app/build/outputs/apk/debug/app-debug.apk"
