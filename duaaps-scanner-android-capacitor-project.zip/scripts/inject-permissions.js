const fs = require('fs');
const path = require('path');

const manifestPath = path.join(__dirname, '..', 'android', 'app', 'src', 'main', 'AndroidManifest.xml');

if (fs.existsSync(manifestPath)) {
  let content = fs.readFileSync(manifestPath, 'utf8');
  let modified = false;

  const permissions = [
    '<uses-permission android:name="android.permission.CAMERA" />',
    '<uses-feature android:name="android.hardware.camera" android:required="false" />',
    '<uses-feature android:name="android.hardware.camera.autofocus" android:required="false" />',
    '<uses-feature android:name="android.hardware.camera.front" android:required="false" />',
    '<uses-permission android:name="android.permission.VIBRATE" />',
    '<uses-permission android:name="android.permission.INTERNET" />',
    '<uses-permission android:name="android.permission.ACCESS_NETWORK_STATE" />'
  ];

  permissions.forEach(perm => {
    const permTag = perm.split(' ')[1];
    if (!content.includes(permTag)) {
      content = content.replace('<application', '    ' + perm + '\n\n    <application');
      modified = true;
    }
  });

  if (modified) {
    fs.writeFileSync(manifestPath, content, 'utf8');
    console.log('✅ Successfully injected Camera & hardware permissions into AndroidManifest.xml!');
  } else {
    console.log('✅ AndroidManifest.xml already contains Camera permissions.');
  }
} else {
  console.log('ℹ️ AndroidManifest.xml will be updated after "npx cap add android".');
}
