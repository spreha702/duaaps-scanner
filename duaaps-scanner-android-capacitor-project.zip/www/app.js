/**
 * DUAAPS Scanner Native App Logic
 * Seamlessly connects to Capacitor ML Kit Barcode Scanner when running on Android
 * and falls back to BarcodeDetector / MediaStream in web browsers.
 */

const WEBAPP_URL = 'https://script.google.com/macros/s/AKfycbzc_G9p-gwpPuC08389OjgPq3HkL3rKOJQ7LDc3rUPQZUsrWZhm_14VYVUdHJYCBeqJ/exec';

let PIN = '';
let EVT = 'ANNUAL REUNION';
let isBusy = false;
let lastScannedText = '';
let lastScanTime = 0;
let lastResultKey = '';
let torchEnabled = false;
let isNative = false;

const $ = id => document.getElementById(id);
const esc = s => String(s == null ? '' : s).replace(/[&<>"]/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));

// Audio & Haptic Feedback
function beep(success) {
  try {
    const AudioCtx = window.AudioContext || window.webkitAudioContext;
    if (AudioCtx) {
      const ctx = new AudioCtx();
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.connect(gain);
      gain.connect(ctx.destination);
      osc.frequency.value = success ? 900 : 220;
      gain.gain.value = 0.15;
      osc.start();
      osc.stop(ctx.currentTime + (success ? 0.14 : 0.35));
    }
  } catch (e) {}

  if (navigator.vibrate) {
    try { navigator.vibrate(success ? 75 : [150, 75, 150]); } catch (e) {}
  }
}

// API Call to Google Apps Script
async function api(payload) {
  const res = await fetch(WEBAPP_URL, {
    method: 'POST',
    headers: { 'Content-Type': 'text/plain;charset=utf-8' },
    body: JSON.stringify(payload),
    redirect: 'follow'
  });
  return res.json();
}

// Check if running inside Capacitor
function checkCapacitor() {
  return typeof window.Capacitor !== 'undefined' && window.Capacitor.isNativePlatform();
}

// Start Scanner (Hybrid: ML Kit Native or Web Camera)
async function startCamera() {
  isNative = checkCapacitor();
  $('camMsg').textContent = 'Starting scanner…';

  if (isNative && window.Capacitor?.Plugins?.BarcodeScanner) {
    // -------------------------------------------------------------
    // NATIVE CAPACITOR ML KIT PIPELINE
    // -------------------------------------------------------------
    try {
      const { BarcodeScanner } = window.Capacitor.Plugins;

      // 1. Request permission
      const status = await BarcodeScanner.requestPermissions();
      if (status.camera !== 'granted') {
        $('camMsg').textContent = 'Camera permission denied';
        return;
      }

      // 2. Make webview transparent so native ML Kit camera shines through
      document.body.classList.add('barcode-scanner-active');

      // 3. Listen for barcodes
      await BarcodeScanner.addListener('barcodeScanned', (result) => {
        if (result && result.barcode && result.barcode.rawValue) {
          handleScanned(result.barcode.rawValue);
        }
      });

      // 4. Start scan restricted to QR Code only for hardware NPU acceleration
      await BarcodeScanner.startScan({
        formats: ['QR_CODE'],
        lensFacing: 'back'
      });

      $('camMsg').textContent = 'Point at QR code (Hardware NPU Active)';
      return;
    } catch (nativeErr) {
      console.warn('Native ML Kit error, falling back to browser stream:', nativeErr);
      document.body.classList.remove('barcode-scanner-active');
    }
  }

  // -------------------------------------------------------------
  // WEB BROWSER FALLBACK PIPELINE
  // -------------------------------------------------------------
  startWebCamera();
}

let webStream = null;
let webVideo = null;
let webDetector = null;
let webRaf = null;

async function startWebCamera() {
  try {
    const stream = await navigator.mediaDevices.getUserMedia({
      video: {
        facingMode: { ideal: 'environment' },
        width: { ideal: 1920 },
        height: { ideal: 1080 }
      },
      audio: false
    });

    webStream = stream;
    const stage = $('stage');
    stage.innerHTML = '';
    webVideo = document.createElement('video');
    webVideo.setAttribute('playsinline', '');
    webVideo.setAttribute('autoplay', '');
    webVideo.muted = true;
    webVideo.srcObject = stream;
    stage.appendChild(webVideo);
    await webVideo.play();

    $('camMsg').textContent = 'Point at a QR code';

    if ('BarcodeDetector' in window) {
      webDetector = new BarcodeDetector({ formats: ['qr_code'] });
      const loop = async () => {
        if (!webVideo) return;
        try {
          const codes = await webDetector.detect(webVideo);
          if (codes && codes.length && codes[0].rawValue) {
            handleScanned(codes[0].rawValue);
          }
        } catch (e) {}
        webRaf = requestAnimationFrame(loop);
      };
      webRaf = requestAnimationFrame(loop);
    }
  } catch (err) {
    $('camMsg').textContent = 'Camera error: ' + (err.message || err);
  }
}

async function stopCamera() {
  if (isNative && window.Capacitor?.Plugins?.BarcodeScanner) {
    try {
      const { BarcodeScanner } = window.Capacitor.Plugins;
      await BarcodeScanner.stopScan();
      await BarcodeScanner.removeAllListeners();
    } catch (e) {}
  }
  document.body.classList.remove('barcode-scanner-active');

  if (webRaf) cancelAnimationFrame(webRaf);
  if (webStream) {
    webStream.getTracks().forEach(t => t.stop());
    webStream = null;
  }
  if (webVideo) {
    webVideo.srcObject = null;
    webVideo = null;
  }
}

// Torch Toggle
$('torchBtn').onclick = async () => {
  torchEnabled = !torchEnabled;
  $('torchBtn').classList.toggle('active', torchEnabled);

  if (isNative && window.Capacitor?.Plugins?.BarcodeScanner) {
    try {
      const { BarcodeScanner } = window.Capacitor.Plugins;
      if (torchEnabled) {
        await BarcodeScanner.enableTorch();
      } else {
        await BarcodeScanner.disableTorch();
      }
    } catch (e) {}
  } else if (webStream) {
    const track = webStream.getVideoTracks()[0];
    if (track && track.applyConstraints) {
      try {
        await track.applyConstraints({ advanced: [{ torch: torchEnabled }] });
      } catch (e) {}
    }
  }
};

// Scan Processor
function extractId(text) {
  let s = String(text || '').trim();
  const m = s.match(/[?&](?:verify|id)=([^&#s]+)/i);
  if (m) {
    try { s = decodeURIComponent(m[1]); } catch (e) { s = m[1]; }
  }
  return s.trim();
}

function handleScanned(rawText) {
  const now = Date.now();
  const val = String(rawText || '').trim();
  if (!val) return;

  // Prevent multiple triggers within 2.5s for same code
  if (val === lastScannedText && now - lastScanTime < 2500) return;
  lastScannedText = val;
  lastScanTime = now;

  // Visual reticle flash
  const frame = $('frame');
  frame.classList.add('scanned');
  setTimeout(() => frame.classList.remove('scanned'), 200);

  submitScan(val);
}

async function submitScan(rawText) {
  if (isBusy || !PIN) return;
  isBusy = true;

  const id = extractId(rawText);
  if (id === lastResultKey) {
    isBusy = false;
    return;
  }
  lastResultKey = id;

  const sheet = $('result');
  const content = $('resultContent');
  content.innerHTML = '<div style="text-align:center;padding:26px;color:#64748b;font-weight:600">Verifying Ticket…</div>';
  sheet.classList.add('show');

  try {
    const res = await api({ action: 'scan', pin: PIN, id: id });
    renderResult(res);
  } catch (err) {
    renderResult({ status: 'ERROR', message: err.message || String(err) });
  }

  isBusy = false;
}

function renderResult(r) {
  const sheet = $('result');
  const content = $('resultContent');

  if (r.error) {
    content.innerHTML = '<div class="banner warn">' + esc(r.error) + '</div>';
    beep(false);
    autoHide(4000);
    return;
  }

  let bannerClass = 'bad';
  let heading = '';
  let sub = '';

  if (r.status === 'OK') {
    bannerClass = 'ok';
    heading = '✔ ' + esc(r.headline || (r.event + ' GRANTED'));
    sub = 'Recorded at ' + esc(r.time);
    beep(true);
    autoHide(2500);
  } else if (r.status === 'DUPLICATE') {
    heading = '✖ ' + esc(r.headline || 'ALREADY SCANNED');
    sub = esc(r.event || 'Entry') + ' first at <b>' + esc(r.time) + '</b>';
    beep(false);
    autoHide(4500);
  } else if (r.status === 'NOT_VERIFIED') {
    bannerClass = 'warn';
    heading = '⚠ PAYMENT UNCONFIRMED';
    sub = esc(r.message || 'Fee verification pending');
    beep(false);
    autoHide(5000);
  } else if (r.status === 'NOT_FOUND') {
    heading = '✖ ID NOT FOUND';
    sub = esc(r.message || 'Record not present in database');
    beep(false);
    autoHide(4000);
  } else if (r.status === 'BAD_PIN') {
    heading = '✖ INVALID PIN';
    sub = esc(r.message);
    beep(false);
    setTimeout(() => {
      stopCamera();
      PIN = '';
      sheet.classList.remove('show');
      $('login').style.display = 'flex';
      $('loginMsg').textContent = r.message;
    }, 800);
    return;
  } else {
    heading = '✖ SCAN ERROR';
    sub = esc(r.message || '');
    beep(false);
    autoHide(3500);
  }

  let html = '<div class="banner ' + bannerClass + '">' + heading + '<small>' + sub + '</small></div>';

  if (r.guestType !== undefined) {
    html += '<div class="badge-info-box">' +
      'Guest: <b>' + esc(r.guestType || '-') + '</b><br>' +
      'Fee: <b>' + esc(r.totalFee || '0') + ' BDT</b><br>' +
      'Attendees: <b>' + esc(r.attendees || '1') + ' person(s)</b>' +
      '</div>';
  }

  if (r.photo) {
    html += '<div class="attendee-card"><img src="' + esc(r.photo) + '" alt="Attendee Photo"></div>';
  }

  if (r.person) {
    html += '<div class="attendee-card">' +
      '<div class="name">' + esc(r.person.name) + '</div>' +
      '<div class="meta">' + esc(r.person.id) +
      (r.person.degree ? ' · ' + esc(r.person.degree) : '') +
      (r.person.membership ? ' · ' + esc(r.person.membership) : '') +
      '</div></div>';
  } else if (r.name) {
    html += '<div class="attendee-card">' +
      '<div class="name">' + esc(r.name) + '</div>' +
      '<div class="meta">' + esc(r.id) +
      (r.degree ? ' · ' + esc(r.degree) : '') +
      (r.session ? ' (' + esc(r.session) + ')' : '') +
      (r.bloodGroup ? ' · Blood ' + esc(r.bloodGroup) : '') +
      '</div></div>';
  }

  if (r.record && r.record.length) {
    html += '<div class="record-list">';
    r.record.forEach(item => {
      html += '<div class="record-row' + (item.key === r.current ? ' active-row' : '') + '">' +
        '<span>' + esc(item.label) + '</span>' +
        (item.time ? '<span class="status-yes">✔ ' + esc(item.time) + '</span>' : '<span class="status-no">— Not yet</span>') +
        '</div>';
    });
    html += '</div>';
  }

  content.innerHTML = html;
  sheet.classList.add('show');
}

let hideTimer = null;
function autoHide(ms) {
  clearTimeout(hideTimer);
  hideTimer = setTimeout(() => {
    $('result').classList.remove('show');
    lastResultKey = '';
  }, ms);
}

// Manual Input Dialog
$('manualBtn').onclick = () => {
  const entered = prompt('Enter Registration ID manually:');
  if (entered && entered.trim()) {
    submitScan(entered.trim());
  }
};

// PIN Unlock Flow
$('loginBtn').onclick = doLogin;
$('pin').onkeydown = e => { if (e.key === 'Enter') doLogin(); };

async function doLogin() {
  const p = $('pin').value.trim();
  if (!p) return;
  $('loginBtn').disabled = true;
  $('loginMsg').textContent = 'Authenticating PIN…';

  try {
    const res = await api({ action: 'login', pin: p });
    if (!res.ok) {
      $('loginMsg').textContent = res.message || 'Incorrect Event PIN';
      $('loginBtn').disabled = false;
      return;
    }
    PIN = p;
    EVT = res.label || 'ANNUAL REUNION';
    $('pin').value = '';
    $('loginMsg').textContent = '';
    $('evName').textContent = EVT.toUpperCase();
    $('login').style.display = 'none';
    try { localStorage.setItem('duaaps_scan_pin', PIN); } catch (e) {}
    setTimeout(startCamera, 150);
  } catch (err) {
    $('loginMsg').textContent = 'Network Error: ' + err.message;
  }
  $('loginBtn').disabled = false;
}

$('changeBtn').onclick = () => {
  stopCamera();
  PIN = '';
  $('result').classList.remove('show');
  $('login').style.display = 'flex';
  $('pin').focus();
};

// Auto-fill saved PIN on load
window.addEventListener('DOMContentLoaded', () => {
  try {
    const saved = localStorage.getItem('duaaps_scan_pin');
    if (saved) $('pin').value = saved;
  } catch (e) {}
});
