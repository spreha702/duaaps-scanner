/**
 * DUAAPS Scanner Native App Logic
 * Ultra-fast verification (<50ms local check), instant startup camera permission,
 * and seamless fallback between Capacitor ML Kit and browser engines.
 */

const WEBAPP_URL = 'https://script.google.com/macros/s/AKfycbzc_G9p-gwpPuC08389OjgPq3HkL3rKOJQ7LDc3rUPQZUsrWZhm_14VYVUdHJYCBeqJ/exec';

let PIN = '';
let EVT = 'ANNUAL REUNION';
let isBusy = false;
let lastScannedText = '';
let lastScanTime = 0;
let lastResultKey = '';
let torchEnabled = false;
let isNative = false;
let turboMode = true; // High-speed gate mode: 0.8s auto-reset

// In-Memory Fast Cache for 0ms Duplicate Check
const localScanCache = new Map();

const $ = id => document.getElementById(id);
const esc = s => String(s == null ? '' : s).replace(/[&<>"]/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));

// Immediate Audio & Haptic Feedback (<5ms)
function beep(success) {
  try {
    const AudioCtx = window.AudioContext || window.webkitAudioContext;
    if (AudioCtx) {
      const ctx = new AudioCtx();
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.connect(gain);
      gain.connect(ctx.destination);
      osc.frequency.value = success ? 950 : 220;
      gain.gain.value = 0.18;
      osc.start();
      osc.stop(ctx.currentTime + (success ? 0.12 : 0.35));
    }
  } catch (e) {}

  if (navigator.vibrate) {
    try { navigator.vibrate(success ? 60 : [120, 60, 120]); } catch (e) {}
  }
}

// Check if running inside Capacitor
function checkCapacitor() {
  return typeof window.Capacitor !== 'undefined' && window.Capacitor.isNativePlatform();
}

// Ensure Camera Permission immediately
async function requestPermissionsOnStartup() {
  isNative = checkCapacitor();
  if (isNative && window.Capacitor?.Plugins?.BarcodeScanner) {
    try {
      const { BarcodeScanner } = window.Capacitor.Plugins;
      let status = await BarcodeScanner.checkPermissions();

      if (status.camera !== 'granted') {
        status = await BarcodeScanner.requestPermissions();
      }

      if (status.camera === 'granted') {
        $('permModal').style.display = 'none';
        return true;
      } else {
        // Show permission dialog with direct settings button
        $('permModal').style.display = 'flex';
        return false;
      }
    } catch (e) {
      console.warn('Permission check error:', e);
    }
  }
  return true;
}

// Start Scanner (Hybrid: ML Kit Native or Web Camera)
async function startCamera() {
  const permOk = await requestPermissionsOnStartup();
  if (!permOk) return;

  $('camMsg').textContent = 'Starting scanner…';

  if (isNative && window.Capacitor?.Plugins?.BarcodeScanner) {
    // -------------------------------------------------------------
    // NATIVE CAPACITOR ML KIT PIPELINE
    // -------------------------------------------------------------
    try {
      const { BarcodeScanner } = window.Capacitor.Plugins;

      // Make webview transparent so native ML Kit camera shines through
      document.body.classList.add('barcode-scanner-active');

      // Listen for barcodes
      await BarcodeScanner.addListener('barcodeScanned', (result) => {
        if (result && result.barcode && result.barcode.rawValue) {
          handleScanned(result.barcode.rawValue);
        }
      });

      // Start scan restricted to QR Code only for maximum hardware speed
      await BarcodeScanner.startScan({
        formats: ['QR_CODE'],
        lensFacing: 'back'
      });

      $('camMsg').textContent = 'Point at QR code (Hardware NPU Active)';
      return;
    } catch (nativeErr) {
      console.warn('Native ML Kit error, falling back to browser stream:', nativeErr);
      document.body.classList.remove('barcode-scanner-active');
    }
  }

  // Web Browser Fallback
  startWebCamera();
}

let webStream = null;
let webVideo = null;
let webDetector = null;
let webRaf = null;

async function startWebCamera() {
  try {
    const stream = await navigator.mediaDevices.getUserMedia({
      video: {
        facingMode: { ideal: 'environment' },
        width: { ideal: 1920 },
        height: { ideal: 1080 }
      },
      audio: false
    });

    webStream = stream;
    const stage = $('stage');
    stage.innerHTML = '';
    webVideo = document.createElement('video');
    webVideo.setAttribute('playsinline', '');
    webVideo.setAttribute('autoplay', '');
    webVideo.muted = true;
    webVideo.srcObject = stream;
    stage.appendChild(webVideo);
    await webVideo.play();

    $('camMsg').textContent = 'Point at a QR code';

    if ('BarcodeDetector' in window) {
      webDetector = new BarcodeDetector({ formats: ['qr_code'] });
      const loop = async () => {
        if (!webVideo) return;
        try {
          const codes = await webDetector.detect(webVideo);
          if (codes && codes.length && codes[0].rawValue) {
            handleScanned(codes[0].rawValue);
          }
        } catch (e) {}
        webRaf = requestAnimationFrame(loop);
      };
      webRaf = requestAnimationFrame(loop);
    }
  } catch (err) {
    $('camMsg').textContent = 'Camera error: ' + (err.message || err);
  }
}

async function stopCamera() {
  if (isNative && window.Capacitor?.Plugins?.BarcodeScanner) {
    try {
      const { BarcodeScanner } = window.Capacitor.Plugins;
      await BarcodeScanner.stopScan();
      await BarcodeScanner.removeAllListeners();
    } catch (e) {}
  }
  document.body.classList.remove('barcode-scanner-active');

  if (webRaf) cancelAnimationFrame(webRaf);
  if (webStream) {
    webStream.getTracks().forEach(t => t.stop());
    webStream = null;
  }
  if (webVideo) {
    webVideo.srcObject = null;
    webVideo = null;
  }
}

// Fast Torch Toggle
$('torchBtn').onclick = async () => {
  torchEnabled = !torchEnabled;
  $('torchBtn').classList.toggle('active', torchEnabled);

  if (isNative && window.Capacitor?.Plugins?.BarcodeScanner) {
    try {
      const { BarcodeScanner } = window.Capacitor.Plugins;
      if (torchEnabled) {
        await BarcodeScanner.enableTorch();
      } else {
        await BarcodeScanner.disableTorch();
      }
    } catch (e) {}
  } else if (webStream) {
    const track = webStream.getVideoTracks()[0];
    if (track && track.applyConstraints) {
      try {
        await track.applyConstraints({ advanced: [{ torch: torchEnabled }] });
      } catch (e) {}
    }
  }
};

// Turbo Mode Toggle
$('turboBtn').onclick = () => {
  turboMode = !turboMode;
  $('turboBtn').classList.toggle('off', !turboMode);
  $('turboStatus').textContent = turboMode ? 'ON' : 'OFF';
};

// Extract clean ID
function extractId(text) {
  let s = String(text || '').trim();
  const m = s.match(/[?&](?:verify|id)=([^&#s]+)/i);
  if (m) {
    try { s = decodeURIComponent(m[1]); } catch (e) { s = m[1]; }
  }
  return s.trim();
}

// Rapid Scan Handler (<10ms optical + audio feedback)
function handleScanned(rawText) {
  const now = Date.now();
  const val = String(rawText || '').trim();
  if (!val) return;

  // Debounce rapid re-scans of the same ticket
  const minInterval = turboMode ? 1800 : 2500;
  if (val === lastScannedText && now - lastScanTime < minInterval) return;
  lastScannedText = val;
  lastScanTime = now;

  // Instant optical reticle pulse
  const frame = $('frame');
  frame.classList.add('scanned');
  setTimeout(() => frame.classList.remove('scanned'), 180);

  submitScan(val);
}

// ULTRA-FAST VERIFICATION ENGINE
async function submitScan(rawText) {
  if (isBusy || !PIN) return;
  isBusy = true;

  const id = extractId(rawText);

  // 1. INSTANT LOCAL CACHE CHECK (<1ms): Did this ticket already enter today?
  if (localScanCache.has(id.toLowerCase())) {
    const cachedTime = localScanCache.get(id.toLowerCase());
    renderResult({
      status: 'DUPLICATE',
      headline: 'ALREADY SCANNED',
      event: 'ENTRY GATE',
      time: cachedTime,
      message: 'Already admitted today at ' + cachedTime + ' (Instant local detection)'
    });
    isBusy = false;
    return;
  }

  // 2. Snappy Optimistic UI
  const sheet = $('result');
  const content = $('resultContent');
  content.innerHTML = '<div style="text-align:center;padding:22px;color:#64748b;font-weight:700">⚡ Verifying ID: ' + esc(id) + '…</div>';
  sheet.classList.add('show');

  // 3. High-Speed API Call with Fast Timeout & Keepalive
  const controller = new AbortController();
  const timeoutId = setTimeout(() => controller.abort(), 6000); // 6s network timeout

  try {
    const res = await fetch(WEBAPP_URL, {
      method: 'POST',
      headers: { 'Content-Type': 'text/plain;charset=utf-8' },
      body: JSON.stringify({ action: 'scan', pin: PIN, id: id }),
      signal: controller.signal,
      keepalive: true
    });
    clearTimeout(timeoutId);

    const data = await res.json();

    // Cache successful scans locally to make subsequent duplicate lookups 0ms instant!
    if (data.status === 'OK') {
      const nowStr = new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
      localScanCache.set(id.toLowerCase(), nowStr);
    }

    renderResult(data);
  } catch (err) {
    clearTimeout(timeoutId);
    renderResult({
      status: 'ERROR',
      message: err.name === 'AbortError' ? 'Network timeout. Check Wi-Fi/4G connection.' : err.message || String(err)
    });
  }

  isBusy = false;
}

function renderResult(r) {
  const sheet = $('result');
  const content = $('resultContent');

  if (r.error) {
    content.innerHTML = '<div class="banner warn">' + esc(r.error) + '</div>';
    beep(false);
    autoHide(3500);
    return;
  }

  let bannerClass = 'bad';
  let heading = '';
  let sub = '';

  if (r.status === 'OK') {
    bannerClass = 'ok';
    heading = '✔ ' + esc(r.headline || (r.event + ' GRANTED'));
    sub = 'Recorded at ' + esc(r.time || 'now');
    beep(true);
    // Snappy auto-hide in turbo mode
    autoHide(turboMode ? 1200 : 2500);
  } else if (r.status === 'DUPLICATE') {
    heading = '✖ ' + esc(r.headline || 'ALREADY SCANNED');
    sub = esc(r.event || 'Entry') + ' first at <b>' + esc(r.time) + '</b>';
    beep(false);
    autoHide(turboMode ? 1800 : 3800);
  } else if (r.status === 'NOT_VERIFIED') {
    bannerClass = 'warn';
    heading = '⚠ PAYMENT UNCONFIRMED';
    sub = esc(r.message || 'Fee verification pending');
    beep(false);
    autoHide(4000);
  } else if (r.status === 'NOT_FOUND') {
    heading = '✖ ID NOT FOUND';
    sub = esc(r.message || 'Record not in registered database');
    beep(false);
    autoHide(3500);
  } else if (r.status === 'BAD_PIN') {
    heading = '✖ INVALID PIN';
    sub = esc(r.message);
    beep(false);
    setTimeout(() => {
      stopCamera();
      PIN = '';
      sheet.classList.remove('show');
      $('login').style.display = 'flex';
      $('loginMsg').textContent = r.message;
    }, 600);
    return;
  } else {
    heading = '✖ SCAN ERROR';
    sub = esc(r.message || '');
    beep(false);
    autoHide(3000);
  }

  let html = '<div class="banner ' + bannerClass + '">' + heading + '<small>' + sub + '</small></div>';

  if (r.guestType !== undefined) {
    html += '<div class="badge-info-box">' +
      'Guest: <b>' + esc(r.guestType || '-') + '</b><br>' +
      'Fee: <b>' + esc(r.totalFee || '0') + ' BDT</b><br>' +
      'Attendees: <b>' + esc(r.attendees || '1') + ' person(s)</b>' +
      '</div>';
  }

  if (r.photo) {
    html += '<div class="attendee-card"><img src="' + esc(r.photo) + '" alt="Attendee Photo"></div>';
  }

  if (r.person) {
    html += '<div class="attendee-card">' +
      '<div class="name">' + esc(r.person.name) + '</div>' +
      '<div class="meta">' + esc(r.person.id) +
      (r.person.degree ? ' · ' + esc(r.person.degree) : '') +
      (r.person.membership ? ' · ' + esc(r.person.membership) : '') +
      '</div></div>';
  } else if (r.name) {
    html += '<div class="attendee-card">' +
      '<div class="name">' + esc(r.name) + '</div>' +
      '<div class="meta">' + esc(r.id) +
      (r.degree ? ' · ' + esc(r.degree) : '') +
      (r.session ? ' (' + esc(r.session) + ')' : '') +
      (r.bloodGroup ? ' · Blood ' + esc(r.bloodGroup) : '') +
      '</div></div>';
  }

  if (r.record && r.record.length) {
    html += '<div class="record-list">';
    r.record.forEach(item => {
      html += '<div class="record-row' + (item.key === r.current ? ' active-row' : '') + '">' +
        '<span>' + esc(item.label) + '</span>' +
        (item.time ? '<span class="status-yes">✔ ' + esc(item.time) + '</span>' : '<span class="status-no">— Not yet</span>') +
        '</div>';
    });
    html += '</div>';
  }

  content.innerHTML = html;
  sheet.classList.add('show');
}

let hideTimer = null;
function autoHide(ms) {
  clearTimeout(hideTimer);
  hideTimer = setTimeout(() => {
    $('result').classList.remove('show');
    lastResultKey = '';
  }, ms);
}

// Manual Input Dialog
$('manualBtn').onclick = () => {
  const entered = prompt('Enter Registration ID manually:');
  if (entered && entered.trim()) {
    submitScan(entered.trim());
  }
};

// Grant Permission Actions
$('grantPermBtn').onclick = async () => {
  $('permModal').style.display = 'none';
  await startCamera();
};

$('openSettingsBtn').onclick = async () => {
  if (isNative && window.Capacitor?.Plugins?.BarcodeScanner) {
    try {
      await window.Capacitor.Plugins.BarcodeScanner.openSettings();
    } catch (e) {}
  }
};

// PIN Unlock Flow
$('loginBtn').onclick = doLogin;
$('pin').onkeydown = e => { if (e.key === 'Enter') doLogin(); };

async function doLogin() {
  const p = $('pin').value.trim();
  if (!p) return;
  $('loginBtn').disabled = true;
  $('loginMsg').textContent = 'Authenticating PIN…';

  try {
    const res = await fetch(WEBAPP_URL, {
      method: 'POST',
      headers: { 'Content-Type': 'text/plain;charset=utf-8' },
      body: JSON.stringify({ action: 'login', pin: p })
    });
    const data = await res.json();

    if (!data.ok) {
      $('loginMsg').textContent = data.message || 'Incorrect Event PIN';
      $('loginBtn').disabled = false;
      return;
    }
    PIN = p;
    EVT = data.label || 'ANNUAL REUNION';
    $('pin').value = '';
    $('loginMsg').textContent = '';
    $('evName').textContent = EVT.toUpperCase();
    $('login').style.display = 'none';
    try { localStorage.setItem('duaaps_scan_pin', PIN); } catch (e) {}
    setTimeout(startCamera, 100);
  } catch (err) {
    $('loginMsg').textContent = 'Network Error: ' + err.message;
  }
  $('loginBtn').disabled = false;
}

$('changeBtn').onclick = () => {
  stopCamera();
  PIN = '';
  try { localStorage.removeItem('duaaps_scan_pin'); } catch (e) {}
  $('result').classList.remove('show');
  $('login').style.display = 'flex';
  $('pin').focus();
};

// Auto-login and Auto-request permissions on app load
window.addEventListener('DOMContentLoaded', async () => {
  // Proactively request camera permissions as soon as app opens
  await requestPermissionsOnStartup();

  try {
    const saved = localStorage.getItem('duaaps_scan_pin');
    if (saved) {
      $('pin').value = saved;
      // Auto-unlock if pin was already saved
      doLogin();
    }
  } catch (e) {}
});
