# DUAAPS Scanner - Native Android APK Project

High-performance native Android QR Scanner powered by **Capacitor** and **Google ML Kit Barcode Scanning**.

---

## ⚡ Key Upgrades in this Build:
1. **Instant Camera Permission Prompt on Launch:**
   - `MainActivity.java` automatically requests `android.permission.CAMERA` as soon as the app opens.
   - Includes fallback dialog with direct "Open Device Settings" button.
2. **Turbo Verification Speed:**
   - In-memory duplicate caching: 0ms instant duplicate alert.
   - Snappy 1.2s auto-dismiss for rapid gate entry.
   - Persistent PIN: Once entered, the scanner auto-opens on all future launches.

---

## 🚀 How to Build the APK

### Option 1: Automatic Cloud Build (No Android Studio Needed!)
1. Push this folder to a GitHub repository (Public or Private).
2. Go to **Actions** tab in GitHub.
3. The workflow `.github/workflows/build-apk.yml` will compile `app-debug.apk` in ~2 minutes.
4. Download the `duaaps-scanner-debug-apk` artifact and install on your phone!

---

### Option 2: Build Locally with Android Studio
1. Open terminal in this folder:
   ```bash
   npm install
   npx cap add android
   npx cap sync android
   ```
2. Open in Android Studio:
   ```bash
   npx cap open android
   ```
3. Click **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
4. Install: `android/app/build/outputs/apk/debug/app-debug.apk`.
