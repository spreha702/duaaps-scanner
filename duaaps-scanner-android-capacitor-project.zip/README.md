# DUAAPS Scanner - Native Android APK Project

High-performance native Android QR Scanner powered by **Capacitor** and **Google ML Kit Barcode Scanning**.

---

## ⚠️ CRITICAL NOTICE: DO NOT RUN `npx cap add android`!
The `android/` directory in this zip is **already 100% generated and pre-configured** with:
- `android.permission.CAMERA` in `AndroidManifest.xml`
- Native Android 14/15 permission prompt in `MainActivity.java`
- Hardware NPU ML Kit scanner integration

Running `npx cap add android` will overwrite and delete the camera permissions!

---

## 🚀 How to Build the APK (2 Easy Ways)

### Option 1: Automatic Cloud Build (No Android Studio Needed!)
1. Push this folder to a GitHub repository (Public or Private).
2. Go to **Actions** tab in GitHub.
3. The workflow `.github/workflows/build-apk.yml` will compile `app-debug.apk` in ~2 minutes.
4. Download the `duaaps-scanner-debug-apk` artifact and install on your phone!

---

### Option 2: Build with Android Studio (Recommended Local Method)
1. Open terminal in this folder:
   ```bash
   npm install
   npm run cap:sync
   ```
2. Open the `android` folder directly in Android Studio:
   ```bash
   npx cap open android
   ```
3. Click **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
4. Your APK will be at:
   `android/app/build/outputs/apk/debug/app-debug.apk`
5. Install on your phone. Camera permission will be asked immediately!
